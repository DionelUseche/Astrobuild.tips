# Starlog

## Release notes theme for Astro

![starlog-gh](https://github.com/doodlemarks/starlog/assets/2244813/9c5c2e46-665a-437e-a971-053db4dbff63)

Built with Astro and Sass. Supports both dark and light modes.
