---
title: Shiki demo
layout: ../layouts/main.astro
---

# Shiki demo

```js
var foo = 'bar';

function doSomething() {
  return foo;
}
```
