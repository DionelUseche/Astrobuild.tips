// Normally this would be in a database.
export const userCartItems = new Map();
