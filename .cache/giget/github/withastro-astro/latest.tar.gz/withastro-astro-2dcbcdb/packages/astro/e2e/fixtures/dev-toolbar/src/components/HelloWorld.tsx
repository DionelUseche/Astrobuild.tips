export function HelloWorld({ name }) {
	return <div>Hello {name}! I'm a component!</div>;
}
