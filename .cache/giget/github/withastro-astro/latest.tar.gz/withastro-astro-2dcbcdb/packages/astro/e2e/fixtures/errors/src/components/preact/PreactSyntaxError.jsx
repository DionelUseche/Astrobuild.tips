import { h } from 'preact';

export default function PreactSyntaxError() {
  return (<div></div></div>);
}
